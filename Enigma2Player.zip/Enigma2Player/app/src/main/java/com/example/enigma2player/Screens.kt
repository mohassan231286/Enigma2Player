package com.example.enigma2player

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.launch

@Composable
fun ListRow(
    title: String,
    sub: String,
    onClick: (() -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val mod = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp)
        .let { if (onClick != null) it.clickable { onClick() } else it }
    Card(modifier = mod) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            leading?.invoke()
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(title, maxLines = 1)
                if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            trailing?.invoke()
        }
    }
}

@Composable
fun BouquetChips(bouquets: List<Item>, selected: String, onSelect: (String) -> Unit) {
    LazyRow(contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items(bouquets) { b ->
            FilterChip(
                selected = b.ref == selected,
                onClick = { onSelect(b.ref) },
                label = { Text(b.name, maxLines = 1) }
            )
        }
    }
}

@Composable
fun Msg(text: String) = Text(text, modifier = Modifier.padding(16.dp))

@Composable
fun ChannelsScreen(play: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bouquets by remember { mutableStateOf<List<Item>>(emptyList()) }
    var bq by remember { mutableStateOf("") }
    var chans by remember { mutableStateOf<List<Item>>(emptyList()) }
    var epg by remember { mutableStateOf<Map<String, Item>>(emptyMap()) }
    var err by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try {
            bouquets = Api.bouquets()
            if (bq.isEmpty() && bouquets.isNotEmpty()) bq = bouquets[0].ref
        } catch (e: Exception) { err = e.message ?: "تعذر الاتصال بالجهاز" }
    }
    LaunchedEffect(bq) {
        if (bq.isEmpty()) return@LaunchedEffect
        try {
            chans = Api.channels(bq)
            epg = Api.epgNow(bq).associateBy { it.ref }
        } catch (e: Exception) { err = e.message ?: "تعذر تحميل القنوات" }
    }

    Column {
        BouquetChips(bouquets, bq) { bq = it }
        if (err.isNotEmpty()) Msg(err)
        LazyColumn {
            items(chans) { c ->
                val p = epg[c.ref]
                ListRow(
                    title = c.name,
                    sub = p?.name ?: "",
                    onClick = {
                        play(Api.streamUrl(c.ref), c.name)
                        scope.launch { runCatching { Api.zap(c.ref) } }
                    },
                    leading = {
                        AsyncImage(
                            model = ImageRequest.Builder(ctx).data(Api.picon(c.ref))
                                .apply { Api.authHeader()?.let { addHeader("Authorization", it) } }
                                .build(),
                            contentDescription = null,
                            modifier = Modifier.size(56.dp, 34.dp)
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun EpgScreen(play: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bouquets by remember { mutableStateOf<List<Item>>(emptyList()) }
    var bq by remember { mutableStateOf("") }
    var events by remember { mutableStateOf<List<Item>>(emptyList()) }
    var err by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try {
            bouquets = Api.bouquets()
            if (bq.isEmpty() && bouquets.isNotEmpty()) bq = bouquets[0].ref
        } catch (e: Exception) { err = e.message ?: "تعذر الاتصال بالجهاز" }
    }
    LaunchedEffect(bq) {
        if (bq.isEmpty()) return@LaunchedEffect
        try { events = Api.epgNow(bq) } catch (e: Exception) { err = e.message ?: "" }
    }

    Column {
        BouquetChips(bouquets, bq) { bq = it }
        if (err.isNotEmpty()) Msg(err)
        LazyColumn {
            items(events) { e ->
                ListRow(
                    title = e.name,
                    sub = "${e.sub} · ${fmt(e.begin)}",
                    onClick = { play(Api.streamUrl(e.ref), e.sub) },
                    trailing = {
                        TextButton(onClick = {
                            scope.launch {
                                try {
                                    Api.addTimer(e)
                                    Toast.makeText(ctx, "تمت إضافة المؤقت", Toast.LENGTH_SHORT).show()
                                } catch (ex: Exception) {
                                    Toast.makeText(ctx, "فشل: ${ex.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { Text("⏰") }
                    }
                )
            }
        }
    }
}

@Composable
fun TimersScreen() {
    val scope = rememberCoroutineScope()
    var timers by remember { mutableStateOf<List<Item>>(emptyList()) }
    var err by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try { timers = Api.timers() } catch (e: Exception) { err = e.message ?: "" }
    }

    Column {
        if (err.isNotEmpty()) Msg(err)
        LazyColumn {
            items(timers) { t ->
                ListRow(
                    title = t.name,
                    sub = "${t.sub} · ${fmt(t.begin)} → ${fmt(t.end)}",
                    trailing = {
                        TextButton(onClick = {
                            scope.launch {
                                runCatching { Api.delTimer(t) }
                                timers = runCatching { Api.timers() }.getOrDefault(timers)
                            }
                        }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                    }
                )
            }
        }
    }
}

@Composable
fun RecordingsScreen(play: (String, String) -> Unit) {
    var recs by remember { mutableStateOf<List<Item>>(emptyList()) }
    var err by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try { recs = Api.recordings() } catch (e: Exception) { err = e.message ?: "" }
    }

    Column {
        if (err.isNotEmpty()) Msg(err)
        LazyColumn {
            items(recs) { r ->
                ListRow(
                    title = r.name,
                    sub = r.sub,
                    onClick = { play(Api.recordingUrl(r.file), r.name) }
                )
            }
        }
    }
}

@Composable
fun M3uScreen(play: (String, String) -> Unit) {
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var items by remember { mutableStateOf<List<Item>>(emptyList()) }
    var err by remember { mutableStateOf("") }

    Column(Modifier.padding(8.dp)) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("رابط ملف M3U أو رابط بث") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                scope.launch {
                    try {
                        items = loadM3u(url.trim())
                        err = ""
                    } catch (e: Exception) { err = e.message ?: "تعذر التحميل" }
                }
            },
            modifier = Modifier.padding(top = 8.dp)
        ) { Text("تحميل") }
        if (err.isNotEmpty()) Msg(err)
        LazyColumn {
            items(items) { i ->
                ListRow(title = i.name, sub = i.ref, onClick = { play(i.ref, i.name) })
            }
        }
    }
}

@Composable
fun SettingsScreen(onSaved: () -> Unit) {
    val ctx = LocalContext.current
    var host by remember { mutableStateOf(Api.host) }
    var user by remember { mutableStateOf(Api.user) }
    var pass by remember { mutableStateOf(Api.pass) }

    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(host, { host = it }, label = { Text("عنوان IP للجهاز") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(user, { user = it }, label = { Text("اسم المستخدم (اختياري)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("كلمة المرور (اختياري)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            Api.save(ctx, host.trim(), user.trim(), pass)
            onSaved()
        }) { Text("حفظ والاتصال") }
    }
}
