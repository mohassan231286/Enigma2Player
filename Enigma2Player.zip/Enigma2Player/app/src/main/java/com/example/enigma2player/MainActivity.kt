package com.example.enigma2player

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultMediaSourceFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Api.load(this)

        val http = DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(15000)
            .setAllowCrossProtocolRedirects(true)
        Api.authHeader()?.let { http.setDefaultRequestProperties(mapOf("Authorization" to it)) }

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App(player)
                }
            }
        }
    }

    // Enter picture-in-picture when the user leaves while something is playing
    override fun onUserLeaveHint() {
        if (player.isPlaying && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPictureInPictureMode(PictureInPictureParams.Builder().build())
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
fun App(player: ExoPlayer) {
    var tab by remember { mutableIntStateOf(0) }
    var nowPlaying by remember { mutableStateOf("") }

    val play: (String, String) -> Unit = { url, title ->
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
        player.play()
        nowPlaying = title
    }

    val titles = listOf("القنوات", "البرامج", "المؤقتات", "التسجيلات", "M3U", "الإعدادات")

    Column(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)
        )
        Text(nowPlaying, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.bodyMedium)

        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
            titles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }

        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> ChannelsScreen(play)
                1 -> EpgScreen(play)
                2 -> TimersScreen()
                3 -> RecordingsScreen(play)
                4 -> M3uScreen(play)
                else -> SettingsScreen(onSaved = { tab = 0 })
            }
        }
    }
}
