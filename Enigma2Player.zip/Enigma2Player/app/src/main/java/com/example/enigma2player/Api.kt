package com.example.enigma2player

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** name = title/channel name, ref = service ref (or stream URL for M3U), sub = secondary text */
data class Item(
    val name: String,
    val ref: String,
    val sub: String = "",
    val begin: Long = 0,
    val end: Long = 0,
    val file: String = ""
)

object Api {
    var host = ""
    var user = ""
    var pass = ""

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("e2", Context.MODE_PRIVATE)
        host = p.getString("host", "") ?: ""
        user = p.getString("user", "") ?: ""
        pass = p.getString("pass", "") ?: ""
    }

    fun save(ctx: Context, h: String, u: String, pw: String) {
        host = h; user = u; pass = pw
        ctx.getSharedPreferences("e2", Context.MODE_PRIVATE).edit()
            .putString("host", h).putString("user", u).putString("pass", pw).apply()
    }

    fun authHeader(): String? =
        if (user.isNotEmpty()) "Basic " + Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP) else null

    fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    fun streamUrl(ref: String) = "http://$host:8001/$ref"
    fun recordingUrl(file: String) = "http://$host/file?file=${enc(file)}"
    fun picon(ref: String) = "http://$host/picon/" + ref.replace(':', '_').trimEnd('_') + ".png"

    private suspend fun get(path: String): JSONObject = withContext(Dispatchers.IO) {
        val c = URL("http://$host$path").openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 15000
        authHeader()?.let { c.setRequestProperty("Authorization", it) }
        try {
            c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } finally {
            c.disconnect()
        }
    }

    private fun arr(o: JSONObject, key: String): List<JSONObject> {
        val a: JSONArray = o.optJSONArray(key) ?: return emptyList()
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    suspend fun bouquets(): List<Item> =
        arr(get("/api/getservices"), "services").map {
            Item(it.optString("servicename"), it.optString("servicereference"))
        }

    suspend fun channels(bRef: String): List<Item> =
        arr(get("/api/getservices?sRef=${enc(bRef)}"), "services")
            .filter { !it.optString("servicename").startsWith("---") }
            .map { Item(it.optString("servicename"), it.optString("servicereference")) }

    /** Current programme per channel in a bouquet. name=title, ref=sref, sub=channel name */
    suspend fun epgNow(bRef: String): List<Item> =
        arr(get("/api/epgnow?bRef=${enc(bRef)}"), "events").map {
            val b = it.optLong("begin_timestamp")
            Item(it.optString("title"), it.optString("sref"), it.optString("sname"),
                b, b + it.optLong("duration_sec"))
        }

    suspend fun timers(): List<Item> =
        arr(get("/api/timerlist"), "timers").map {
            Item(it.optString("name"), it.optString("serviceref"), it.optString("servicename"),
                it.optLong("begin"), it.optLong("end"))
        }

    suspend fun addTimer(i: Item) {
        get("/api/timeradd?sRef=${enc(i.ref)}&begin=${i.begin}&end=${i.end}" +
            "&name=${enc(i.name)}&description=&disabled=0&justplay=0&afterevent=3")
    }

    suspend fun delTimer(i: Item) {
        get("/api/timerdelete?sRef=${enc(i.ref)}&begin=${i.begin}&end=${i.end}")
    }

    suspend fun recordings(): List<Item> =
        arr(get("/api/movielist"), "movies").map {
            Item(it.optString("title"), "", it.optString("servicename"), file = it.optString("filename"))
        }

    suspend fun zap(ref: String) { get("/api/zap?sRef=${enc(ref)}") }
}

fun fmt(ts: Long): String =
    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(ts * 1000))

/** Reads an M3U playlist, or treats the input as a single stream URL. */
suspend fun loadM3u(src: String): List<Item> = withContext(Dispatchers.IO) {
    val head = URL(src).openStream().use { String(it.readNBytes(16)) }
    if (!head.startsWith("#EXTM3U")) return@withContext listOf(Item(src, src))
    val text = URL(src).readText()
    val out = mutableListOf<Item>()
    var name = ""
    for (line in text.lines()) {
        val s = line.trim()
        when {
            s.startsWith("#EXTINF") -> name = s.substringAfter(',', "").trim()
            s.isNotEmpty() && !s.startsWith("#") -> {
                out += Item(name.ifEmpty { s }, s)
                name = ""
            }
        }
    }
    out
}
